from setuptools import setup

setup(name='submitter_utils_ppp_p4',
      version='1.0',
      description='Sail() submission tools',
      url='https://sailplatform.org/',
      author='Jaromir Savelka',
      author_email='jsavelka@cs.cmu.edu',
      packages=['submitter_utils'],
      include_package_data=True,
      zip_safe=False)
